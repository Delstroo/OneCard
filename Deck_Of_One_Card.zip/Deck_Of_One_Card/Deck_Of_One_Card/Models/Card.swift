//
//  Card.swift
//  Deck_Of_One_Card
//
//  Created by Delstun McCray on 8/3/21.
//

import Foundation

struct TopLevelObject: Decodable {
    
    let success: Bool
    let cards: [Card]
}

struct Card: Decodable {
    
    let value: String
    let suit: String
    let image: URL
}

//struct Card: Decodable {
//
//    let value: String
//    let suit: String
//    let image: URL
//
//    struct topLevelObject: Decodable {
//        let cards: [Card]
//    }
//
//}//end of struct
